# Hibernate Image Example

Demonstrates how to save/load an image from MySQL using Hibernate.

## Post - Blog - Step by Step

* Portuguese: http://www.loiane.com/2011/10/como-salvar-e-fazer-load-de-imagens-usando-hibernate-e-mysql/
* English: http://loianegroner.com/2011/10/how-to-load-or-save-image-using-hibernate-mysql/


## More Tutorials

* Loiane Groner
* http://loianegroner.com (English)
* http://loiane.com (Portuguese)