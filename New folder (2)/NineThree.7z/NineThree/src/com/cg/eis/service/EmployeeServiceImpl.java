package com.cg.eis.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeExceptionImpl;
import com.cg.eis.exception.IEmployeeException;

public class EmployeeServiceImpl implements IEmployeeService{

	@Override
	public void InsuranceScheme() {
		// TODO Auto-generated method stub
		
	}
	
	

	@Override
	public void InsuranceScheme(int salary, String designation) throws EmployeeExceptionImpl {
		// TODO Auto-generated method stub
		if(salary <  3000) {
			throw new EmployeeExceptionImpl(IEmployeeException.ERROR1);
		}
		if((salary > 5000 && salary < 20000) && designation.equals("systemassociate")) {
			System.out.println("scheme C");
		}
		else if((salary >= 20000 && salary < 40000) && designation.equals("programmer")) {
			System.out.println("scheme B");
		}
		else if((salary >= 40000) && designation.equals("manager")) {
			System.out.println("scheme A");
		}
		else if((salary < 5000) && designation.equals("clerk")) {
			System.out.println("Noscheme");
		}
		else {
			System.out.println("salary or designation is not matched..please enter correct ones");
		}
		
	}



	@Override
	public void FileObject(Employee details) {
		File file = new File("D://Users//learning//Desktop//EmployeeDet.txt");
		FileOutputStream fos;
		try {
			fos = new FileOutputStream(file);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(details);
			oos.close();
			
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
			//e.printStackTrace();
		} catch (IOException e) {
			//e.printStackTrace();
		} 
	}



	@Override
	public void FileObjectDetails(Employee emp){
		// TODO Auto-generated method stub
		
		try {
			File file = new File("D://Users//learning//Desktop//EmployeeDet.txt");
			FileInputStream fileInputStream;
			fileInputStream = new FileInputStream(file);
			ObjectInputStream inputStream;
			inputStream = new ObjectInputStream(fileInputStream);
			Employee empOne = (Employee) inputStream.readObject();
			System.out.println(empOne.getId());
			System.out.println(empOne.getName());
			System.out.println(empOne.getSalary());
			System.out.println(empOne.getDesignation());
			System.out.println(empOne.getInsuranceScheme());
			inputStream.close();
			fileInputStream.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	
		
		
	}

}
