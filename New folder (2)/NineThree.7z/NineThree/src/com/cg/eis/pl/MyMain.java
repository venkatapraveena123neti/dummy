package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeExceptionImpl;
import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.service.IEmployeeService;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			Scanner sc = new Scanner(System.in);
	       Employee emp = new Employee();
	       
	       System.out.println("enter name");
	       String empName = sc.next();
	       System.out.println("enter id");
	       int empId = sc.nextInt();
	       System.out.println("enter Designation");
	       String empDesignation = sc.next();
	       System.out.println("enter salary");
	       int empSal = sc.nextInt();
	       System.out.println("enter scheme");
	       String empScheme = sc.next();
	       
	       emp.setName(empName);
	       emp.setId(empId);
	       emp.setDesignation(empDesignation);
	       emp.setInsuranceScheme(empScheme);
		   emp.setSalary(empSal);
		
	       
	       System.out.println(emp.toString());
	       IEmployeeService service = new EmployeeServiceImpl();
	       
	      
	       
	       int sal = emp.getSalary();
	       //System.out.println(sal);
	       String des = emp.getDesignation();
	       //System.out.println(des);
	       try {
			service.InsuranceScheme(sal, des);
		} catch (EmployeeExceptionImpl e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	       service.FileObject(emp);
	       service.FileObjectDetails(emp);
	       
	       
	       
	       
	       
	}

}