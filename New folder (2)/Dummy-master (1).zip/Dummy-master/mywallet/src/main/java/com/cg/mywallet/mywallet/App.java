package com.cg.mywallet.mywallet;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "VARUN" );
        System.out.println("fsdgd");
    }
}
