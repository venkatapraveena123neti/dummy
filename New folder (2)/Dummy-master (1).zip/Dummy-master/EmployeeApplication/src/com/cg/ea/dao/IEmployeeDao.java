package com.cg.ea.dao;

import com.cg.ea.beans.Employee;

public interface IEmployeeDao {

	int add(Employee employee);

}
