package com.cg.flp.DemoFlpProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoFlpProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoFlpProjectApplication.class, args);
	}
}
