package com.cg.libraryproject.exception;

public interface ILibraryException {
	String ERROR1 = "Invalid..Try Again";

}
