package com.cg.libraryproject.exception;

public class LibraryException extends Exception{
	public LibraryException() {
		super();
	}
	public LibraryException(String arg0) {
		super(arg0);
	}

}
