package com.cg.libraryproject.dao;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.libraryproject.exception.LibraryException;
import com.cg.libraryproject.service.ILibraryService;
import com.cg.libraryproject.service.LibraryServiceImpl;

public class LibraryTestCase {
	
	@BeforeClass
	public static void setup() {
		System.out.println("testing started");
	}
	@AfterClass
	public static void getup() {
		System.out.println("testing completed");
	}

	@Test(expected = LibraryException.class)
	public void testId() throws LibraryException{
		ILibraryService service = new LibraryServiceImpl();
		
		
			service.payAmount("1010priya");
		
		
	}
	@Test()
	public void testIdOne() {
		ILibraryService service = new LibraryServiceImpl();
		service.viewDetails("10010priya");
		
	}
	@Test(expected = LibraryException.class)
	public void payamounttest() throws LibraryException {
		ILibraryService service = new LibraryServiceImpl();
		service.payAmount("101Priya");
		
	}
	

}
